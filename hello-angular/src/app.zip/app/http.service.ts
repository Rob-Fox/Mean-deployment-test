import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})


export class HttpService {
  constructor(private _http: HttpClient) {
    this.getTasks();
    this.findTasks('5af8b2d4097bc4cc8218179c');
   }

  getTasks(ID) {
    console.log(ID);
    const tempObservable1 = this._http.get('/tasks/' + ID);
    tempObservable1.subscribe(data => console.log('Got our tasks!', data));
  }
  // createTasks() {
  //   const tempObservable2 = this._http.post('/tasks', values);
  //   tempObservable2.subscribe(data => console.log('Created new task!', data));
  // }
  findTasks() {
    const tempObservable3 = this._http.get('/tasks/+id');
    tempObservable3.subscribe(data => console.log('Got our task with id: ', data));
  }
  // editTasks() {
  //   const tempObservable4 = this._http.put('/tasks/+id', values);
  //   tempObservable4.subscribe(data => console.log('Edited task with id: ', data));
  // }
  deleteTasks() {
    const tempObservable5 = this._http.delete('/tasks/+id');
    tempObservable5.subscribe(data => console.log('Deleted task with id: ', data));
  }

}
